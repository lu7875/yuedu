package io.legado.app.help.http

enum class RequestMethod {
    GET, POST
}