# android服务

* AudioPlayService 音频播放服务
* CheckSourceService 书源检测服务
* DownloadService 缓存服务
* HttpReadAloudService 在线朗读服务
* TTSReadAloudService tts朗读服务
* WebService web服务