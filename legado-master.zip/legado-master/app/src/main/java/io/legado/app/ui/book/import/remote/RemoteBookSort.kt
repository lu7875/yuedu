package io.legado.app.ui.book.import.remote

enum class RemoteBookSort {
    Default, Name
}